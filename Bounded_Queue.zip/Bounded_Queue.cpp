/*      
 *      Bounded_Queue.cpp
 *      
 *      programmed by Dorian Pistilli
 *      Last edit on 10/28/14
 *      Language used: C++
 *
 *      A bounded queue data structure designed for the KPCB Fellows
 *      application. It offers the client a bounded queue for storing "n"
 *      integers, with n being a size they can set initially but remains
 *      static once set.
 *
 *      Implemented using a circular buffer to store the ints, and head
 *      and tail ints to keep track of which indices should be popped from
 *      or pushed to next.
 *      
 *      A circular buffer was chosen over a linked list because there's 
 *      less overhead (large L.Lists are storage heavy w/ Node pointers)
 *      and because it offers O(1) enQ/deQ operations vs O(n) for linked
 *      list.
 *
 *      I had some issues with one of the requirements in the spec that the
 *      applicant refrain from including any libraries, and relying solely
 *      on primitive types. Although its understandable that the use of
 *      pre-built data structures would defeat the challenge, it also puts
 *      restrictions on effective programming practices. In the end, I
 *      decided to use the iostream and exception libraries. I found this
 *      necessary, because without them I could not properly handle several
 *      potential errors, like running out of dynamic mem when allocating
 *      the new array, or trying to dequeue an empty list.
 *
 *      I hope this does not violate the contract given too much, but I
 *      figured it would be better to have a fully-functioning program than
 *      fit a somewhat overly-stringent spec.
 *      
 *      Potential Changes (for future use):
 *
 *       - A different functionality before release!! I much prefer allowing
 *         the client to have both <dequeue> AND <front> functions. This 
 *         gives enqueue and dequeue similar functionality of just pushing 
 *         and popping, and leaves the returning of information to <front>. 
 *         This removes the awkward case where the user is popping from an 
 *         empty list AND expecting to have an int returned... ooh awk.
 */      


#include "Bounded_Queue.hpp"
#include <iostream> // for printing exceptions to the cerr stream
#include <exception> //for throwing/catching necessary exceptions

/************************************************
*                                               *
*            Constructor/Destructor             *
*                                               *
************************************************/

Bounded_Queue::Bounded_Queue(int q_size)
{
        this->curr_size = 0;
        this->max_size = q_size;

        try {
               this->queue = new int[q_size];
        }
        catch (std::exception& std_e) {
                std::cerr << "Error: " << std_e.what() << std::endl;
        } 

        this->head = this->tail = 0;
}

Bounded_Queue::~Bounded_Queue()
{
        delete[] this->queue;
}

/************************************************
*                                               *
*             Public/Client Functions           *
*                                               *
************************************************/

bool Bounded_Queue::enqueue(int input)
// Function: Allows the client to push one int onto the queue and
//           returns whether or not the push was a success
//     Args: int (the integer to be pushed onto the queue)
//  Returns: bool (returns 1 if push was successful or 0 if queue was full)
{
        if (is_full()) {
                return 0;
        } else {
                set_in_array(input, tail);
                curr_size++;
                tail++;
                tail = this->tail % max_size;
                return 1;
        }
}

int Bounded_Queue::dequeue()
// Function: Allows the client to pop one int off of the queue and
//           returns that value
//     Args: n/a
//  Returns: int (the number being popped off)
//    Notes: Throws std::logic_error if called on an empty queue
{
        if (is_empty()) {
                std::string error = "Error: Attempting to dequeue from "
                                    "an empty queue\n";
                throw std::logic_error(error);
        } else {
                int temp_index = head;
                curr_size--;
                head++;
                head = head % max_size;
                return get_from_array(temp_index); 
        }
}


  
/************************************************
*                                               *
*            Private/Helper Functions           *
*                                               *
************************************************/

void Bounded_Queue::set_in_array(int val, int index)
{
        this->queue[index] = val;
}

int Bounded_Queue::get_from_array(int index)
{
        return queue[index];
}

// is_full() and and is_empty() are fairly intuitive,
// returning 1 if is_condition and 0 if not
bool Bounded_Queue::is_full()
{
        if (curr_size >= max_size) {
                return 1;
        } else {
                return 0;
        }
}

bool Bounded_Queue::is_empty()
{
        if (curr_size == 0) {
                return 1;
        } else {
                return 0;
        }
}
