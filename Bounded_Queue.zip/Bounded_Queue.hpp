#ifndef __BOUNDED_QUEUE_INCLUDED__
#define __BOUNDED_QUEUE_INCLUDED__

class Bounded_Queue {
        public:
                Bounded_Queue(int q_size);
                ~Bounded_Queue();

                bool enqueue(int input);
                int dequeue();
        private:
                bool is_full();
                bool is_empty();

                void set_in_array(int val, int index);
                int get_from_array(int index);

                int max_size, curr_size, head, tail;
                int* queue;
};




#endif // __BOUNDED_QUEUE_INCLUDED__
